export const People = [
  {
    name: "Pedro",
    email: "email@email.com",
    age: 21,
    isMarried: true,
    friends: ["jessica"],
  },
];
