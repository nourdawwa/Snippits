export const Contact = () => {
  return <h1> THIS IS THE CONTACT PAGE</h1>;
};
